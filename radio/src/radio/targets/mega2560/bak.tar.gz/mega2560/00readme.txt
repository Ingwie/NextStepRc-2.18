MEGA2560 board

======================= DESCRIPTION =======================
DIY radio wih :
- Arduino MEGA2560 or compatible
- Gruvin9x features (soft-off, SD-Card, RTC, haptic, voice, rotary encoders)
- LCD 128x64 8 bits parallel mode
- home made case